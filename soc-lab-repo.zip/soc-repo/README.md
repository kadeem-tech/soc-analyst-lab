# SOC Analyst Lab — Wazuh EDR/SIEM Detection & Response

A self-built, hands-on Security Operations Center lab simulating the
detection and response workflow used by managed SOC platforms (e.g.
SentinelOne). Built as preparation for a SOC Analyst internship, this
project covers the full lifecycle: infrastructure setup, live attack
simulation, detection triage, and incident reporting.

## Why Wazuh instead of SentinelOne?

SentinelOne is enterprise software with no public/self-hosted access.
**Wazuh** was chosen deliberately because it mirrors the same underlying
model — agent-based endpoint monitoring, real-time alerting, MITRE ATT&CK
mapping, and centralized incident triage — making it a realistic, honest
stand-in for demonstrating the same analyst workflow.

## Architecture

```
┌─────────────────────────┐        ┌──────────────────────────┐
│     Wazuh-Manager        │        │       Endpoint-01          │
│   Ubuntu 26.04 LTS        │◄──────►│    Ubuntu 26.04 LTS         │
│   10.0.2.3                │  agent │    10.0.2.4                 │
│                            │  data  │                              │
│  • Wazuh Manager           │        │  • Wazuh Agent               │
│  • Wazuh Indexer           │        │  • SSH server (attack target)│
│  • Wazuh Dashboard         │        │                              │
└─────────────────────────┘        └──────────────────────────┘
        VirtualBox NAT Network (isolated lab environment)
```

## What's in this repo

| Path | Contents |
|---|---|
| `docs/SOC_Incident_Report.docx` / `.pdf` | Full incident report — NIST-style structure, MITRE ATT&CK mapping, compliance mapping, triage assessment, and remediation recommendations |
| `configs/active-response.xml` | Wazuh manager config for automated IP blocking on brute-force detection |
| `configs/agent-install-notes.md` | Commands used to install and register the Wazuh agent |
| `configs/attack-simulation.md` | Attack techniques simulated and the commands used |
| `screenshots/` | Dashboard and detection screenshots |

## Summary of findings

- **99 correlated security events** generated from a simulated SSH
  brute-force attack (MITRE ATT&CK **T1110 — Brute Force**)
- Wazuh correctly escalated individual failed-login events into a single
  high-confidence, correlated alert (**Rule 5712, Level 10**)
- Detection mapped to real compliance controls (**GDPR, HIPAA, SOC 2 TSC**)
- Identified a **File Integrity Monitoring coverage gap** in default
  configuration — a realistic, common production tuning issue
- Configured **active response** (automated firewall blocking); documented
  partial validation and next debugging steps honestly rather than
  overstating results

Full write-up, timeline, and recommendations in the [incident report](docs/SOC_Incident_Report.pdf).

## Tools & Skills Demonstrated

- SIEM/EDR deployment and configuration (Wazuh)
- Linux system administration (Ubuntu Server, VirtualBox networking)
- Log analysis and alert triage
- MITRE ATT&CK framework mapping
- Compliance framework awareness (GDPR, HIPAA, SOC 2)
- Incident response documentation (NIST 800-61-aligned structure)
- Active response / automated containment configuration

## Author

[Your Name] — built as a hands-on project ahead of a SOC Analyst internship
interview.
